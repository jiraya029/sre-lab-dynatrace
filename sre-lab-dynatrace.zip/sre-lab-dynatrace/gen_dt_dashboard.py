#!/usr/bin/env python3
"""Generates sre-lab-dynatrace-dashboard.json (Dynatrace Dashboards app, DQL tiles)
mirroring the Grafana / New Relic 'SRE Lab - Full Observability' dashboard."""
import json, pathlib

tiles, layouts = {}, {}
_id = [0]
pos = {"x": 0, "y": 0, "h": 0}
W = 24


def nid():
    _id[0] += 1
    return str(_id[0])


def _flush():
    if pos["x"] or pos["h"]:
        pos["y"] += pos["h"]; pos["x"] = 0; pos["h"] = 0


def place(w, h):
    if pos["x"] + w > W:
        _flush()
    lay = {"x": pos["x"], "y": pos["y"], "w": w, "h": h}
    pos["x"] += w; pos["h"] = max(pos["h"], h)
    return lay


def section(title, note=""):
    _flush()
    i = nid()
    tiles[i] = {"type": "markdown", "content": f"## {title}" + (f"\n{note}" if note else "")}
    layouts[i] = {"x": 0, "y": pos["y"], "w": W, "h": 2}
    pos["y"] += 2


def tile(title, query, viz="lineChart", w=8, h=6):
    i = nid()
    tiles[i] = {"type": "data", "title": title, "query": query, "visualization": viz,
                "visualizationSettings": {}, "querySettings": {}, "davis": {"enabled": False}}
    layouts[i] = place(w, h)


# ------------------------------------------------------------ Golden Signals
section("Demo App - Golden Signals", "Prometheus metrics scraped by Dynatrace from the demo-app pods.")
tile("Request Rate (req/s)", "timeseries rate = sum(http_requests_total, rate:1s)")
tile("Error Rate (%)", 'timeseries { err = sum(http_requests_total, rate:1s, filter: { startsWith(status, "5") }), total = sum(http_requests_total, rate:1s) }\n| fieldsAdd error_pct = err[] / total[] * 100\n| fields timeframe, interval, error_pct')
tile("Requests by Status Code", "timeseries rate = sum(http_requests_total, rate:1s), by: { status }")
tile("Average Latency (s)", "timeseries { s = sum(http_request_duration_seconds_sum), c = sum(http_request_duration_seconds_count) }\n| fieldsAdd avg_latency = s[] / c[]\n| fields timeframe, interval, avg_latency", w=12)
tile("Total Requests", "timeseries t = sum(http_requests_total), nonempty: true\n| fieldsAdd total_requests = arraySum(t)\n| fields total_requests", "singleValue", w=6)
tile("Demo App Pods Available", 'timeseries p = max(kube_deployment_status_replicas_available, filter: { deployment == "demo-app" }), nonempty: true\n| fieldsAdd pods = arrayLast(p)\n| fields pods', "singleValue", w=6)

# ------------------------------------------------------------ Host health (node-exporter)
section("Node Exporter - Host Health", "Same node-exporter metrics as the other dashboards.")
tile("CPU Cores", 'timeseries c = sum(node_cpu_seconds_total, filter: { mode == "idle" }, by: { cpu }), nonempty: true\n| summarize cores = count()', "singleValue", w=6, h=5)
tile("Running Processes", "timeseries p = max(node_procs_running), nonempty: true\n| fieldsAdd v = arrayLast(p)\n| fields v", "singleValue", w=6, h=5)
tile("Blocked Processes", "timeseries p = max(node_procs_blocked), nonempty: true\n| fieldsAdd v = arrayLast(p)\n| fields v", "singleValue", w=6, h=5)
tile("Memory Usage (%)", "timeseries { a = avg(node_memory_MemAvailable_bytes), t = avg(node_memory_MemTotal_bytes) }\n| fieldsAdd mem_pct = (1 - a[] / t[]) * 100\n| fields timeframe, interval, mem_pct", w=6, h=5)
tile("Busy CPU Cores", 'timeseries b = sum(node_cpu_seconds_total, rate:1s, filter: { mode != "idle" })', w=12)
tile("CPU Usage by Mode (cores)", 'timeseries b = sum(node_cpu_seconds_total, rate:1s, filter: { mode != "idle" }), by: { mode }', w=12)
tile("Memory Detail (bytes)", "timeseries { total = avg(node_memory_MemTotal_bytes), available = avg(node_memory_MemAvailable_bytes), cached = avg(node_memory_Cached_bytes), buffers = avg(node_memory_Buffers_bytes) }", w=12)
tile("Disk Usage / (%)", 'timeseries { a = avg(node_filesystem_avail_bytes, filter: { mountpoint == "/" }), s = avg(node_filesystem_size_bytes, filter: { mountpoint == "/" }) }\n| fieldsAdd used_pct = (1 - a[] / s[]) * 100\n| fields timeframe, interval, used_pct', w=12)
tile("Disk I/O (bytes/s)", "timeseries { read = sum(node_disk_read_bytes_total, rate:1s), write = sum(node_disk_written_bytes_total, rate:1s) }", w=12)
NIC = 'device != "lo" AND NOT startsWith(device, "veth") AND NOT startsWith(device, "cni") AND NOT startsWith(device, "flannel")'
tile("Network Traffic (bytes/s)", f"timeseries {{ rx = sum(node_network_receive_bytes_total, rate:1s, filter: {{ {NIC} }}), tx = sum(node_network_transmit_bytes_total, rate:1s, filter: {{ {NIC} }}) }}", w=12)
tile("Network Errors & Drops (/s)", f"timeseries {{ rx_err = sum(node_network_receive_errs_total, rate:1s, filter: {{ {NIC} }}), tx_err = sum(node_network_transmit_errs_total, rate:1s, filter: {{ {NIC} }}), rx_drop = sum(node_network_receive_drop_total, rate:1s, filter: {{ {NIC} }}), tx_drop = sum(node_network_transmit_drop_total, rate:1s, filter: {{ {NIC} }}) }}", w=12)
tile("Load Average", "timeseries { load1 = avg(node_load1), load5 = avg(node_load5), load15 = avg(node_load15) }", w=12)

# ------------------------------------------------------------ Logs
section("Logs", "Needs log monitoring enabled in the DynaKube (see README).")
tile("All App Logs", 'fetch logs\n| filter k8s.namespace.name == "app"\n| sort timestamp desc\n| limit 100\n| fields timestamp, k8s.pod.name, content', "table", w=24, h=8)
tile("Error Logs Only", 'fetch logs\n| filter k8s.namespace.name == "app"\n| filter matchesPhrase(content, "error") or matchesPhrase(content, "failure") or contains(content, "\\" 500 ")\n| sort timestamp desc\n| limit 100\n| fields timestamp, k8s.pod.name, content', "table", w=24, h=8)
tile("Log Volume Over Time", 'fetch logs\n| filter k8s.namespace.name == "app"\n| makeTimeseries lines = count(), interval: 1m', w=24, h=6)

# ------------------------------------------------------------ Alerting
section("Alerting", "Dynatrace (Davis) problems. Prometheus ALERTS series are not scraped here.")
tile("Latest Davis Problems", "fetch dt.davis.problems\n| sort timestamp desc\n| limit 20\n| fields timestamp, display_id, event.name, event.status", "table", w=24, h=7)

# ------------------------------------------------------------ Kubernetes
section("Kubernetes Cluster")
tile("Running Pods", 'timeseries p = sum(kube_pod_status_phase, filter: { phase == "Running" }), nonempty: true\n| fieldsAdd v = arrayLast(p)\n| fields v', "singleValue", w=6, h=5)
tile("Running Containers", "timeseries c = sum(kube_pod_container_status_running), nonempty: true\n| fieldsAdd v = arrayLast(c)\n| fields v", "singleValue", w=6, h=5)
tile("Demo App: Desired vs Available Replicas", 'timeseries { desired = max(kube_deployment_spec_replicas, filter: { deployment == "demo-app" }), available = max(kube_deployment_status_replicas_available, filter: { deployment == "demo-app" }) }', w=12, h=5)
tile("CPU Usage by Pod (app namespace)", 'timeseries cpu = avg(dt.kubernetes.container.cpu_usage), by: { k8s.pod.name }, filter: { k8s.namespace.name == "app" }', w=12)
tile("Memory Usage by Pod (app namespace)", 'timeseries mem = avg(dt.kubernetes.container.memory_working_set), by: { k8s.pod.name }, filter: { k8s.namespace.name == "app" }', w=12)
tile("Autoscaling: HPA Current vs Desired Replicas", "timeseries { current = max(kube_horizontalpodautoscaler_status_current_replicas), desired = max(kube_horizontalpodautoscaler_status_desired_replicas) }", w=24)

# ------------------------------------------------------------ Ansible
section("Ansible Remediation Activity")
tile("Total Remediation Attempts", "timeseries t = sum(remediation_attempts_total), nonempty: true\n| fieldsAdd v = arraySum(t)\n| fields v", "singleValue", w=8, h=5)
tile("Successful Remediations", 'timeseries t = sum(remediation_attempts_total, filter: { outcome == "success" }), nonempty: true\n| fieldsAdd v = arraySum(t)\n| fields v', "singleValue", w=8, h=5)
tile("Failed Remediations", 'timeseries t = sum(remediation_attempts_total, filter: { outcome == "failure" }), nonempty: true\n| fieldsAdd v = arraySum(t)\n| fields v', "singleValue", w=8, h=5)
tile("Remediation Attempts Over Time", "timeseries t = sum(remediation_attempts_total), by: { alertname, outcome }", w=24)
tile("Ansible Webhook Logs", 'fetch logs\n| filter k8s.namespace.name == "monitoring" and matchesValue(k8s.pod.name, "ansible-webhook*")\n| sort timestamp desc\n| limit 100\n| fields timestamp, content', "table", w=24, h=8)

dash = {"version": 18, "variables": [], "tiles": tiles, "layouts": layouts,
        "importedWithCode": False, "settings": {}}
out = pathlib.Path(__file__).with_name("sre-lab-dynatrace-dashboard.json")
out.write_text(json.dumps(dash, indent=1))
print(f"wrote {out}: {sum(1 for t in tiles.values() if t['type']=='data')} data tiles, {sum(1 for t in tiles.values() if t['type']=='markdown')} section headers")
